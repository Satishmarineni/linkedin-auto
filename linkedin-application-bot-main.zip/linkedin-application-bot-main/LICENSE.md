

_____________________________________________________  
  
  
LINKEDIN APPLY BOT SOFTWARE LICENSE & EULA  
  
______________________________________________________  
  
  
SOFTWARE LICENSING:  
  
LINKEDIN APPLY BOT is covered under a proprietary based license. 

LICENSE TERMS:  
  
LINKEDIN APPLY BOT for personal use only.  
  
  
LINKEDIN APPLY BOT for commercial use.  
  