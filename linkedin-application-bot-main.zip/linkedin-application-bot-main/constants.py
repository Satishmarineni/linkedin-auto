linkJobUrl = "https://www.linkedin.com/jobs/search/"
angelCoUrl = "https://angel.co/login"
globalLogicUrl = "https://www.globallogic.com/career-search-page/"

jobsPerPage = 25

fast = 2
medium = 3
slow = 5 

botSpeed = slow

# TO DO ADD OTHER PRINT CONSTANTS
