jobsPerPage = 25

fast = 2
medium = 3
slow = 5 

botSpeed = medium

# TO DO ADD OTHER PRINT CONSTANTS
